package com.mystudy.io6_object;

public class ObjectInputOutputStream_List {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
