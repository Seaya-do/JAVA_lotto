package com.mystudy.am03_scanner_bank;

public class BankATMTest {

	public static void main(String[] args) {
		BankATM atm = new BankATM();
		atm.startBank();
	}

}
