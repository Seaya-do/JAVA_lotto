package com.mystudy.am02_scanner_game;

public class GuessNumberGameMain {

	public static void main(String[] args) {
		GuessNumberGame game = new GuessNumberGame();
		game.startGame();

	}

}
