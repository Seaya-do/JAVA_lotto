package com.mystudy.pm03_overriding;

public class Sheep extends Animal {
	@Override
	void sound() {
		System.out.println(">> �޿�~~~");;
	}
}
