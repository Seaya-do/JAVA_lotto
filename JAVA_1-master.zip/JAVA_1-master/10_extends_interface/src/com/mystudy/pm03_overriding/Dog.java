package com.mystudy.pm03_overriding;

public class Dog extends Animal {

	void sound() {
		System.out.println(">> ��~��~");
	}
}
