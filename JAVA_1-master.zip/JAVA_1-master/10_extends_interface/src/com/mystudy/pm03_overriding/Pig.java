package com.mystudy.pm03_overriding;

public class Pig extends Animal {
	void sound() {
		System.out.println(">> �ܲ�~~");
	}
}
