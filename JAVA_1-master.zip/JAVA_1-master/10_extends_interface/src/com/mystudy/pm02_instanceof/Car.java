package com.mystudy.pm02_instanceof;

public class Car {
	String type;
	
	void drive() {
		System.out.println(">> �̵�");
	}
	
	void stop() {
		System.out.println(">> ����");
	}
}
