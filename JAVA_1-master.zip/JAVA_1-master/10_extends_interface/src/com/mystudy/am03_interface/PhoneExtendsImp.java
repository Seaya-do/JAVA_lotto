package com.mystudy.am03_interface;

public class PhoneExtendsImp extends Phone implements I_Mp3Phone {

	@Override
	public void playMusic() {
		
	}

}
