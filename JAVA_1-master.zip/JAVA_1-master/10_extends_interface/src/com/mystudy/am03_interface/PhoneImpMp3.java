package com.mystudy.am03_interface;

public class PhoneImpMp3 implements I_Mp3Phone {

	@Override
	public void view() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void call() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void receiveCall() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sendMsg() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void receiveMsg() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void playMusic() {
		// TODO Auto-generated method stub
		
	}

}
